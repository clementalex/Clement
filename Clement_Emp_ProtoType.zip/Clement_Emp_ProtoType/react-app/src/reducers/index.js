import { combineReducers } from "redux";
import { employeeReducers } from "./emploeeReducers";

export const reducers = combineReducers({
    employeeReducers
})